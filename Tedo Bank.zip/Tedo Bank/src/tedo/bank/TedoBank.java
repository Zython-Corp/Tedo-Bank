package tedo.bank;

public class TedoBank {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int Dbe_Amount=500;
        String Message="Hi! Amount of Rs."+Dbe_Amount+" has been Debited Successfully.\nThanks for Supporting with us.\n\n\t<- Have a Great Day ->\n\nFor Contact (send mail at) :\nzythonencoders@gmail.com";
        System.out.println(Message);
    }
    
    
}
